import { base44 } from '@/api/base44Client';

export class NotificationManager {
  static async registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/service-worker.js');
        console.log('Service Worker registered:', registration);
        return registration;
      } catch (error) {
        console.error('Service Worker registration failed:', error);
      }
    }
  }

  static async requestPermission() {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return false;
    }

    if (Notification.permission === 'granted') {
      return true;
    }

    if (Notification.permission !== 'denied') {
      try {
        const permission = await Notification.requestPermission();
        return permission === 'granted';
      } catch (error) {
        console.error('Error requesting notification permission:', error);
        return false;
      }
    }

    return false;
  }

  static async subscribeToPushNotifications() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      console.log('Push notifications not supported');
      return null;
    }

    try {
      const registration = await navigator.serviceWorker.ready;
      let subscription = await registration.pushManager.getSubscription();

      if (!subscription) {
        const vapidPublicKey = import.meta.env.VITE_VAPID_PUBLIC_KEY || '';
        
        if (vapidPublicKey) {
          subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: this.urlBase64ToUint8Array(vapidPublicKey),
          });
        }
      }

      return subscription;
    } catch (error) {
      console.error('Push subscription failed:', error);
      return null;
    }
  }

  static urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  static async sendNotification(userEmail, title, body, type, referenceId) {
    try {
      await base44.functions.invoke('sendPushNotification', {
        user_email: userEmail,
        title,
        body,
        type,
        reference_id: referenceId,
      });
    } catch (error) {
      console.error('Failed to send notification:', error);
    }
  }

  static async notifyNewMessage(senderName, message, conversationId, isUrgent = false) {
    const title = isUrgent ? `🚨 Urgent: ${senderName}` : `💬 ${senderName}`;
    const body = message.substring(0, 100);
    
    await this.sendNotification(
      null,
      title,
      body,
      'message',
      conversationId
    );
  }

  static async notifyUrgentConversation(conversationTitle, conversationId) {
    const title = '⚠️ Urgent Conversation';
    const body = conversationTitle;
    
    await this.sendNotification(
      null,
      title,
      body,
      'message',
      conversationId
    );
  }

  static async markNotificationAsRead(notificationId) {
    try {
      await base44.entities.Notification.update(notificationId, { read: true });
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  }
}

if (typeof window !== 'undefined') {
  window.addEventListener('load', () => {
    NotificationManager.registerServiceWorker();
  });
}